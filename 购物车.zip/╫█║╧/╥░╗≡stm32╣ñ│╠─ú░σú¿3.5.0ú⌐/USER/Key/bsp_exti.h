#ifndef __EXTI_H
#define	__EXTI_H

#include "stm32f10x.h"
void EXTI_PA0_Config(void);

#endif /* __EXTI_H */
