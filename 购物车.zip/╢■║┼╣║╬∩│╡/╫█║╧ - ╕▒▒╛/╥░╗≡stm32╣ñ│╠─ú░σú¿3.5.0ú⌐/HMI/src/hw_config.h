#ifndef _HW_CONFIG_H
#define _HW_CONFIG_H
void Set_System(void);
void Interrupts_Config(void);
#endif
