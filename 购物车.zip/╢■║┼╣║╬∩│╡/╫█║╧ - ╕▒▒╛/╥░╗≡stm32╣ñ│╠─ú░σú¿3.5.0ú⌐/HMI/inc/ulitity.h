#ifndef _ULITITY_H
#define _ULITITY_H
void systicket_init(void);
void UpDate(void);
void iniuserctr(void);
void delay_ms(uint32 delay);
#endif
