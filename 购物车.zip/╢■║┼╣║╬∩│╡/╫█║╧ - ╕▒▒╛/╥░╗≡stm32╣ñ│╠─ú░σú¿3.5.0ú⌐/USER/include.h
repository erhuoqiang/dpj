#ifndef _INCLUDE_H_
#define _INCLUDE_H_

#include "stm32f10x.h"
#include "bsp_usart1.h"
#include "bsp_led.h"
#include "bsp_exti.h"
#include "bsp_SysTick.h"
#include "bsp_TiMbase.h"
#include "stdio.h"
#include "bsp_pwm_output.h" 
#include "bsp_adc.h"
#include "bsp_i2c_ee.h"
#include "bsp_gpio_spi.h"
#include "bsp_touch.h"
#include "bsp_ili9341_lcd.h"
#include "cmd_queue.h"
#include "hmi_driver.h"
#include "cmd_process.h"
#include "string.h"
#include <stdarg.h>
#include <stdlib.h>
#include "bsp_sdio_sdcard.h"
#include "ff.h"

#endif 
