/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "include.h"
volatile unsigned char touch_flag;

extern void TimingDelay_Decrement(void);
/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */

void SysTick_Handler(void)
{
		TimingDelay_Decrement();
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/
char mode = 0;//����2 ������ɨ�軹����Ʒ����
extern char v; //�������յ���λ��
void EXTI0_IRQHandler(void)
{
	if(EXTI_GetFlagStatus(EXTI_Line0) != RESET)
	{
		LED1_TOGGLE;
		LED2_TOGGLE; //��ƴ�����Ʒ���룬���ƴ���������ɨ��
		//mode ^= 0x01;
		v = 0;//����ͬʱҲ���Խ�����������ո�λ
		//GPIOC->ODR ^= GPIO_Pin_3;
		EXTI_ClearFlag(EXTI_Line0);
		
	}
}
void EXTI4_IRQHandler(void)
{ 
  if(EXTI_GetITStatus(EXTI_Line4) != RESET)
  {	
    touch_flag=1;

    EXTI_ClearITPendingBit(EXTI_Line4);
  }
}
extern int flag;
void USART2_IRQHandler(void)
{
	uint8_t ch;
	TIM_SetCounter(TIM2, 0);
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{ 	
	    //ch = USART1->DR;//LCD_DisNum(160, 90, ch, RED);	
			ch = USART_ReceiveData(USART2);
	  	//printf( "%c", ch );    //�����ܵ�������ֱ�ӷ��ش�ӡ
			queue_push(ch);
	
	} 
	 
}

/*extern uint16 screen_id;                  //ҳ��ID��ű���
extern uint16 control_id; 
extern uint8 cmd_type;
extern  uint8 msg_type;
extern  uint8 control_type;
extern PCTRL_MSG msg;
extern int  size;
extern volatile uint16 current_screen_id; //��ǰ��Ļ���ڵĻ����ű���
extern volatile uint32  timer_tick_count; //��ʱ�����ı���
*/
typedef struct 
{
	char name[20];
	char num[20];
	char mon[10];
	char CODE[14];
	char times;
} good; //��Ʒ��Ϣ
extern good a[500];
int count = 0;//ɨ����Ʒ����
float sum = 0; // ����Ʒ��
float money[26] = {0};
float get_cost(char * cost) // �۸��ַ�ת��������
{
	float temp = 0;
	uchar	i = 0;
	while( cost[i] != '.' )
	{
		temp = cost[i] - 48 + temp*10;
		i++;
	}
	temp = temp + (cost[ i + 1 ] - 48)/10.0;
	return temp;
}

typedef struct
{
	char num;
	char times;
} Sort;
Sort sort[50] = {0}; //ͳ��50��������Ʒ��������
void search(char *code) //�ҵ��������Ӧ����Ʒ�۸� ������Զ��ۼ�
{
	 
	int i = 0, j = 0;
	 char n = 0;
	char temp[10] = {0};
	v = 0;//������λ����λ
	while( strlen(a[n].name) > 1 )
		{
			n++;
		}
	//	USART_SendData(USART2, n);
		//SetTextValue( 2, 7,(unsigned char*)a[1].name);
	for( j = 0; j < n; j++)
		{
			
			for(i = 0; i < 13; i++)
			{
				
				if( code[i] == a[j].CODE[i] )
				{
				;
				}
				else
				{
				break;
				}
			}
			if( i == 13)
			{
				if(count < 12)
				{
					a[j].times++;
					SetTextValue( 2, 3 + 2 * count,(unsigned char*)a[j].name);
					SetTextValue( 2, 4 + 2 * count,(unsigned char*)a[j].mon);
					money[count] = get_cost(a[j].mon);
					sum += money[count];
					sprintf(temp, "%.2f", sum);
					SetTextValue( 2, 50,(unsigned char*)temp);
					SetTextValue( 5, 50,(unsigned char*)temp);
					count++;
				}
				else if( count >= 12)
				{
					SetScreen(5);
					a[j].times++;
					SetTextValue( 5, 1 + 2 * (count-12),(unsigned char*)a[j].name);
					SetTextValue( 5, 2 + 2 * (count-12),(unsigned char*)a[j].mon);
					money[count] = get_cost(a[j].mon);
					sum += money[count];
					sprintf(temp, "%.2f", sum);;
					SetTextValue( 2, 50,(unsigned char*)temp);
					SetTextValue( 5, 50,(unsigned char*)temp);
					count++;
					if(count == 26 )
						count = 0;
				}
					
				break;
			}
		}
	
}
int flag = 0;
int j = 0, k = 0, m = 0, h = 0,i = 0;
char code[14], v = 0;
char tempre = 0;
char advertisement[200]; 
int c = 0;  //��������λ��
void USART1_IRQHandler(void)
{
	//uint8_t ch;
	TIM_SetCounter(TIM2, 0);
	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
	{ 	
		tempre = USART_ReceiveData(USART1);
		if(tempre == '^')
		{	
			//LED1_ON;
			mode = 1;
			USART_printf(USART1, "\r\n �������Ʒ�� \r\n");
			return;
		}
		if(tempre == '&')
		{
			//LED1_OFF;
			mode = 0;
			USART_printf(USART1, "\r\n ����������ģʽ�� \r\n");
			return;
		}
		if(tempre == '*')
		{
			//LED1_OFF;
			mode = 2;
			USART_printf(USART1, "\r\n ����¹�����ַ�'-'������\r\n");
			c = 0; //��渴λ
			return;
		}

		if(mode == 1)
		{
		code[0] = tempre;
		if(code[0] == '!')
		{flag = 0;return;}
		else if(code[0] == '@')
			{flag = 1;return;}
		else if(code[0] == '#')
			{flag = 2;return;}
		else if(code[0] == '$')
			{flag = 3;return;}
		else if(code[0] == '%')
			{flag = 4;i++;return;}
		
			
		switch(flag)
		{
			case 0:
				m = 0;
				a[i].name[j] = code[0];
				j++;//LED1_TOGGLE
				break;
			case 1:
				j = 0;
				a[i].num[k] = code[0];
			k++;//LED2_TOGGLE;
				break;
			case 2:
				k = 0;
				a[i].mon[h] = code[0];//LED3_TOGGLE;
			  h++;
				break;
			case 3:
				h = 0;
			 a[i].CODE[m] = code[0];//LED1_TOGGLE;
			 m++;break;
			default:
				//USART2_printf(USART1, "%s",a[0].CODE);
		//	LED1_TOGGLE;
			break;
		}
		}
			
		else if( mode == 0 )
		{
			//LED1_TOGGLE;
	    //ch = USART1->DR;//LCD_DisNum(160, 90, ch, RED);	
			code[v] = USART_ReceiveData(USART1);
			 
			//USART_SendData(USART2, code[i]);
			v++;
			if( v == 13 )
			{
				v = 0;
				//SetTextValue( 2, 9,(unsigned char*)code);
				search(code);
			}
		}
		else if(mode == 2)
		{
			if( USART_ReceiveData(USART1) == '-' )
			{
				SetTextValue( 7, 2,(unsigned char*)advertisement);
				USART_printf(USART1, "\r\n �����³ɹ��� \r\n");
				advertisement[c] = '\0';
				c = 0;
				return;
			}
			advertisement[c] = USART_ReceiveData(USART1);
			c++;
		}
	} 
	 
}

void TIM2_IRQHandler(void)
{
	if ( TIM_GetITStatus(TIM2 , TIM_IT_Update) != RESET ) 
	{	
		//LED3_TOGGLE;
		SetScreen(7);
		TIM_ClearITPendingBit(TIM2 , TIM_FLAG_Update);  	
		//CLOSE_TIM2_BASETIME;		
	}		 	
}
/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
