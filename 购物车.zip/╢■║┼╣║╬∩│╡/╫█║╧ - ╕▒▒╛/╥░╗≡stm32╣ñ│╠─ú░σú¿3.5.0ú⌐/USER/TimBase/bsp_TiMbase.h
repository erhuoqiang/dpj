#ifndef TIME_TEST_H
#define TIME_TEST_H

#include "stm32f10x.h"

#define STAT_TIM2_BASETIME RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , ENABLE);
#define CLOSE_TIM2_BASETIME RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , DISABLE);
static void TIM2_NVIC_Configuration(void);
void TIM2_Configuration(u16 ms_10);

#endif	/* TIME_TEST_H */
